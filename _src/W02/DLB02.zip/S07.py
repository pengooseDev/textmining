from nltk.tokenize import word_tokenize

para = "Hello everyone. It's good to see you. Let's start our text mining class!"
print(word_tokenize(para))  # 주어진 text를 word 단위로 tokenize함
