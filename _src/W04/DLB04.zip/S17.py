import pandas as pd

df = pd.read_csv('../data/daum_movie_review.csv')
print(df.head(10))
