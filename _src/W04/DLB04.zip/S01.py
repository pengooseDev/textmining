import nltk

nltk.download('movie_reviews')
nltk.download('punkt')
